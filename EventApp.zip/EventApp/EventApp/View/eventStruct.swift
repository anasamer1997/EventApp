//
//  eventStruct.swift
//  AlamofireApp
//
//  Created by mac on 31/12/2020.
//

import Foundation
import UIKit

struct Eventstruct: Decodable {

    let eventImage:String
    let eventName:String
    let companyName:String
    let eventAddress:String
    let eventDate:String

}
