//
//  EventCell.swift
//  AlamofireApp
//
//  Created by mac on 31/12/2020.
//

import UIKit

class EventCell: UITableViewCell {

    var safeArea : UILayoutGuide!
    var Eventimg = UIImageView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // Setup
    func setupView() {
        safeArea = layoutMarginsGuide
        setupImageView()
    }
    
    func setupImageView(){
        addSubview(Eventimg)
    
        Eventimg.translatesAutoresizingMaskIntoConstraints = false
        Eventimg.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor).isActive = true
        Eventimg.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        Eventimg.widthAnchor.constraint(equalToConstant: 50).isActive = true
        Eventimg.heightAnchor.constraint(equalToConstant: 50).isActive = true
        Eventimg.backgroundColor = #colorLiteral(red: 0.108221643, green: 0.2216927408, blue: 1, alpha: 0.8768086212)
        
        
        
    
    }
    
 
    
    
    
    
    
}
