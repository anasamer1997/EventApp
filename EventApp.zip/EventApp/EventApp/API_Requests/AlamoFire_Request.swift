//
//  AlamoFire_Request.swift
//  AlamofireApp
//
//  Created by mac on 06/01/2021.
//

import Foundation
import Alamofire
import FirebaseDatabase

private let DB_ref = Database.database().reference()
private var EventsInfo = DB_ref.child("Events Information")


class Request{
    
    static let instance = Request()

//    var event_name = ""
//    var Date = ""
//    var Location = ""
//    var Oraganization = ""
//    // عرل في الفورمات بتاع ال json  عشان يبقى فيه اسم الايفينت بدا ماتخلس اسمه هو id
//    func GetEventsFromFirebaseDB(){
//        EventsInfo.observeSingleEvent(of: .value, with: { (snapshot) in
//        if let event = EventStruct(snapshot: snapshot) {
//            self.event_name = event.event_name
//            self.Date = event.Date
//            self.Location = event.Location
//            self.Oraganization = event.Oraganization
//            
//        } else {
//            print("New user!")
//        }
//        })
//    }
    
    
    //upload event data
    
    // alamofire request
    func AddEvent(event_name:String, date:String,location:String,organization:String){
        let para = [
            "event_name":"\(event_name)",
            "Date":"\(date)",
            "Location":"\(location)",
            "Oraganization":"\(organization)"
        ]
        AF.request("http://localhost:3000/EventsInformation/",method: .post,parameters: para,encoding: JSONEncoding.default,headers: nil).validate(statusCode: 200 ..< 299).responseJSON{ AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                    print("Error: Cannot convert JSON object to Pretty JSON data")
                    return
                }
                guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                    print("Error: Could print JSON in String")
                    return
                }
                print(prettyPrintedJson)
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }

    }
    
    // update event data
    func UpdateEvent(event_name:String, date:String,location:String,org:String){  // id is needed
        let para = [
            "event_name":"\(event_name)",
            "Date":"\(date)",
            "Location":"\(location)",
            "Oraganization":"\(org)"
        ]
        AF.request("http://localhost:3000/EventsInformation/",method: .put,parameters: para,encoding: JSONEncoding.default,headers: nil).validate(statusCode: 200 ..< 299).responseJSON{ AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                    print("Error: Cannot convert JSON object to Pretty JSON data")
                    return
                }
                guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                    print("Error: Could print JSON in String")
                    return
                }
                print(prettyPrintedJson)
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        }
    }
    
    
    // delete event data
    func DeleteEvent(event_name:String){
        AF.request("http://localhost:3000/EventsInformation/\(event_name)",method: .delete,parameters: nil,encoding: JSONEncoding.default,headers: nil).validate(statusCode: 200 ..< 299).responseJSON{ AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                    print("Error: Cannot convert JSON object to Pretty JSON data")
                    return
                }
                guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                    print("Error: Could print JSON in String")
                    return
                }
                print(prettyPrintedJson)
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
        
        }

    }
}
