//
//  datepickerVC.swift
//  AlamofireApp
//
//  Created by mac on 16/01/2021.
//

import UIKit

class datepickerVC: UIViewController {

    
    @IBOutlet var datepicker: UITextField!
    
    let picker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createDatePicker()
        // Do any additional setup after loading the view.
    }
    
    func createDatePicker() {
        let toolBar = UIToolbar()
            toolBar.sizeToFit()

            
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(Donedatepicker))
            
        toolBar.setItems([done] , animated: true)
            
        datepicker.inputAccessoryView = toolBar
            // assign date picker to bearthdate
        datepicker.inputView = picker
        picker.datePickerMode = .date
        
        
    }
    @objc func Donedatepicker(){
        
    
        
        
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        datepicker.text = formatter.string(from: picker.date)
        self.view.endEditing(true)
    }
    

}
