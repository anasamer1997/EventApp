//
//  LanguageVC.swift
//  AlamofireApp
//
//  Created by mac on 28/12/2020.
//

import UIKit
import DropDown
class LanguageVC: UIViewController {

        
    @IBOutlet weak var showLanguage: UITabBar!
    
    
    
    let menu:DropDown = {
        let menu = DropDown()
        menu.dataSource = ["AR" , "EG" , "FR"]
        return menu
    }()
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

      
        
    }
    

    @IBAction func backHome(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(identifier: "ShowVC") as? ShowVC else{
            return
        }
        dismiss(animated: true, completion: nil)
    }
    
}
