//
//  ChangePasswordVC.swift
//  AlamofireApp
//
//  Created by mac on 17/01/2021.
//

import UIKit

class ChangePasswordVC: UIViewController {

    @IBOutlet weak var Old_Password: UITextField!
   
    @IBOutlet weak var New_Password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func Save_newPassword(_ sender: Any) {
    }
    

    @IBAction func BackBTN(_ sender: Any) {
    }
}
