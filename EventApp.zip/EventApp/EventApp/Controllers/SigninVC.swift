//
//  SigninVC.swift
//  AlamofireApp
//
//  Created by mac on 28/12/2020.
//
import SCLAlertView
import UIKit
import FirebaseDatabase

private let DB_ref = Database.database().reference()
class SigninVC: UIViewController {

    static let instance = SigninVC()
    var validation = Validation()
    @IBOutlet weak var UserNumberTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
        
    func gotoSignInPage(){
        guard let mobileNum = UserNumberTF.text else{return}
        let isValidmobile = self.validation.validaPhoneNumber(phoneNumber: "\(UserNumberTF.text!)")
        if isValidmobile == false{
            SCLAlertView().showError("Error", subTitle: "Number not found!")
        }else{
        DataServices.instance.getUserData(UserMobile: "\(UserNumberTF.text!)")
        DataServices.instance.signInBtn(mobileNum: "\(UserNumberTF.text!)")
        guard let vc = storyboard?.instantiateViewController(identifier: "ShowVC") as? ShowVC else{
            return 
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated: true)
            }
        }
    
    @IBAction func signinBackHomeBtn(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func SigninBtn(_ sender: Any) {
        gotoSignInPage()
    }
}
