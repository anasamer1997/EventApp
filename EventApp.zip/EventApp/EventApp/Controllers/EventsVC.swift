//
//  EventsVC.swift
//  AlamofireApp
//
//  Created by mac on 28/12/2020.
//

import UIKit
import FirebaseDatabase

class EventsVC: UIViewController{
    static let instance = EventsVC()
    
    let tableview = UITableView()
    var safeArea : UILayoutGuide!
    var events = [EventStruct]()
    @IBOutlet weak var topview: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.dataSource = self
        tableview.delegate = self
        tableview.register(UITableViewCell.self, forCellReuseIdentifier: "eventcell")
        safeArea = view.layoutMarginsGuide
        setupView()
        
        GetEvents {
            self.tableview.reloadData()
        }
    }
    
    func GetEvents(completed: @escaping ()->()){
        let url = URL(string: "http://localhost:3000/Events_Information/")!
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if error == nil{
                do{
                    self.events = try JSONDecoder().decode([EventStruct].self, from: data!)
                    DispatchQueue.main.async {
                        completed()
                    }
                }catch{
                    print("JSON Error")
                }
            }
        }
        task.resume()

    }
    
    func setupView(){
        view.addSubview(tableview)
      //  tableview.register(EventCell.self, forCellReuseIdentifier: "eventcell")
        tableview.translatesAutoresizingMaskIntoConstraints = false
        tableview.topAnchor.constraint(equalTo: topview.bottomAnchor).isActive = true
        tableview.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        tableview.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        tableview.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
    }
    
    
    @IBAction func backHomeBtn(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

}

extension EventsVC: UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    // show events name
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "eventcell",for: indexPath)
        cell.textLabel?.text = events[indexPath.row].event_name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let eventselect = events[indexPath.row].event_name
        guard let vc = storyboard?.instantiateViewController(identifier: "RegistarationVC") as? RegistarationVC else{return}
        vc.eventselected = eventselect
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated: true)
    }
}
