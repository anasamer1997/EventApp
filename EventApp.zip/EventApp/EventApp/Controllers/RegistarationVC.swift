import UIKit

class RegistarationVC: UIViewController {

    static let instance = RegistarationVC()
    
    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var mobilNumTF: UITextField!
    @IBOutlet weak var GenderTF: UITextField!
    @IBOutlet weak var BearthDateTF: UITextField!
  
    // hold event selected data
    var eventselected = ""
    var validation = Validation()
    let userDate = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createDatepicker()
    }
    
    func checkUserRegistration(){
        guard let name = userNameTF.text , let email = emailTF.text ,let gender = GenderTF.text , let mobile = mobilNumTF.text ,
              let date = BearthDateTF.text else {
            return
        }
//        name.trimmingCharacters(in: .whitespacesAndNewlines)
        let isValidName = self.validation.validateName(name: name)
        if (isValidName == false) {
           print("Incorrect Name")
           return
        }
       
        let isValidEmail = self.validation.validateEmailId(emailID: email)
        if (isValidEmail == false) {
           print("Incorrect Email")
           return
        }
        
        let isValidPhone = self.validation.validaPhoneNumber(phoneNumber: mobile)
        if (isValidPhone == false) {
           print("Incorrect Phone")
           return
        
        }
       
        if (isValidEmail == true && isValidPhone == true && isValidName == true){
            DataServices.instance.registaration(uname: name, email: email, gender: GenderTF.text!, mobileNum: mobile, date_of_birth: BearthDateTF.text!, eventType: eventselected)
            
            guard let vc = storyboard?.instantiateViewController(identifier: "ShowVC") as? ShowVC else{
                return
            }
            vc.modalPresentationStyle = .fullScreen
            present(vc,animated: true)
        }
        
        
        
    }
        
     
    func createDatepicker() {
    let toolBar = UIToolbar()
        toolBar.sizeToFit()

        let done = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(Donedatepicker))
        toolBar.setItems([done] , animated: true)
        
        BearthDateTF.inputAccessoryView = toolBar
        // assign date picker to bearthdate
        BearthDateTF.inputView = userDate
        userDate.datePickerMode = .date
    }
    
    @objc func Donedatepicker(){
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        BearthDateTF.text = formatter.string(from: userDate.date)
        self.view.endEditing(true)
    }
    
    
    @IBAction func saveData(_ sender: Any) {
        checkUserRegistration()
    }
    
    @IBAction func RegisterationBackHomeBtn(_ sender: Any) {
         dismiss(animated: true, completion: nil)
    }
    
}
    
