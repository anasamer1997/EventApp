//
//  CreateAccountVC.swift
//  AlamofireApp
//
//  Created by mac on 28/12/2020.
//

import UIKit
class CreateAccountVC: UIViewController {

    static let instance = CreateAccountVC()
    var validation = Validation()
    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var userEmailTF: UITextField!
    @IBOutlet weak var userMobileNumTF: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    func checkUserData(){
        guard let name = userNameTF.text , let email = userEmailTF.text , let mobile = userMobileNumTF.text ,let pass = userPassword.text else {
            return
        }
        
        let isValidName = self.validation.validateName(name: name)
        if (isValidName == false) {
           print("Incorrect Name")
           return
        }
       
        let isValidEmail = self.validation.validateEmailId(emailID: email)
        if (isValidEmail == false) {
           print("Incorrect Email")
           return
        }
        let isValidPassword = self.validation.validatePassword(password: pass)
        if (isValidEmail == false) {
           print("Incorrect password")
           return
        }
        let isValidPhone = self.validation.validaPhoneNumber(phoneNumber: mobile)
        if (isValidPhone == false) {
           print("Incorrect Phone")
           return
        }
        if (isValidEmail == true || isValidPhone == true || isValidName == true && isValidPassword == true){
            DataServices.instance.createAccount(uName: name, email: email, mobile: mobile,password: pass)
        }
    }
    //MARK - IBAction :
    @IBAction func CreateBtnPressed(_ sender: Any) {
        checkUserData()
        guard let vc = storyboard?.instantiateViewController(identifier: "ShowVC") as? ShowVC else{
            return
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated: true)
    }
    
 
    @IBAction func BackBtn(_ sender: Any) {
       dismiss(animated: true, completion: nil)
       
    }
   
    @IBAction func goToSigninPage(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(identifier: "SigninVC") as? SigninVC else{
            return
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated: true)
    }
    
    
    
    
}

