//
//  OTPVC.swift
//  AlamofireApp
//
//  Created by mac on 17/01/2021.
//

import UIKit
import Foundation


class OTPVC: UIViewController ,UITextFieldDelegate{

    @IBOutlet weak var OTP_TF: UITextField!
    @IBOutlet weak var resend: UIButton!
    @IBOutlet weak var reset: UIButton!
    
    var sendOTP:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sendOTP = DataServices.instance.mobile
        getOTP()
    }
    
    func getOTP(){
        if let mobile:String = sendOTP{
            OTP_Serviec().getVerificationId(phoneNumber: mobile) { (id, error) in
                if error != nil {
                    return
                }
                if let id = id {
                    self.displayAlert(id: id)
                }
            }
        }
    }
    
    
    func displayAlert(id: String) {
           let alertController = UIAlertController(title: "OTP?", message: "", preferredStyle: .alert)
            
           let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
               (action : UIAlertAction!) -> Void in
           })
            
           let saveAction = UIAlertAction(title: "Save", style: .default, handler: {
               alert -> Void in
                
               let otpText = alertController.textFields![0] as UITextField
               if let otp = otpText.text {
                   print(otp)
                    
                   OTP_Serviec().signIn(verificationId: id, verificationCode: otp){ (status, error) in
                       if error != nil {
                           return
                       }
                        
                       print("SignIn status", status ?? "Unknown")
                   }
               }
           })
            
           alertController.addTextField { (textField : UITextField!) -> Void in
               textField.placeholder = "OTP"
           }
            
           alertController.addAction(cancelAction)
           alertController.addAction(saveAction)
            
           self.present(alertController, animated: true, completion: nil)
       }
    
    
    
    @IBAction func ResendOTP(_ sender: Any) {
        
    }
    @IBAction func Reset(_ sender: Any) {
    }
    
    @IBAction func backBTN(_ sender: Any) {
    }
}
