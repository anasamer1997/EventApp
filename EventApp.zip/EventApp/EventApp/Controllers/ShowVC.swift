//
//  ViewController.swift
//  AlamofireApp
//
//  Created by mac on 26/12/2020.
//

import UIKit

class ShowVC : UIViewController {

    @IBOutlet weak var customerName: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }


    @IBAction func EventsBtn(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(identifier: "EventsVC") as? EventsVC else {
            return
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated: true)
    }
        
    
    @IBAction func MyTicketBtn(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(identifier: "MyTicketVC") as? MyTicketVC else {
            return
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated: true)
    }
    
    @IBAction func ProfileBtn(_ sender: Any) {
        guard let vc = storyboard?.instantiateViewController(identifier: "ProfileVC") as? ProfileVC else {
            return
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc,animated: true)
    }
    
    @IBAction func LanguageBtn(_ sender: Any) {
//        guard let vc = storyboard?.instantiateViewController(identifier: "LanguageVC") as? LanguageVC else {
//            return
//        }
//        vc.modalPresentationStyle = .fullScreen
//        present(vc,animated: true)
    }
    
    
}

