//
//  ProfileVC.swift
//  AlamofireApp
//
//  Created by mac on 28/12/2020.
//

import UIKit
import FirebaseDatabase


class ProfileVC: UIViewController {
    
    static let instance = ProfileVC()
  //  var userdata = [String]()
    @IBOutlet weak var unameLabel: UILabel!
    @IBOutlet weak var uemailLabel: UILabel!
    @IBOutlet weak var uphoneLabel: UILabel!
    @IBOutlet weak var ueventsLabel: UILabel!
    
    // create table view
    override func viewDidLoad() {
        super.viewDidLoad()
       // DataServices.instance.getUserData(UserMobile: umobile)
        unameLabel.text = DataServices.instance.name
        uemailLabel.text = DataServices.instance.email
        uphoneLabel.text = DataServices.instance.mobile
    
    }
    
    @IBAction func backBTN(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveChanges(_ sender: Any) {
    }
    @IBAction func editInfo(_ sender: Any) {
    
    }
}
