//
//  DataServices.swift
//  AlamofireApp
//
//  Created by mac on 02/01/2021.
//

import Foundation
import FirebaseDatabase

private let DB_ref = Database.database().reference()

class DataServices{
    
    private var registareation_events = DB_ref.child("Registered Event")
    private var users = DB_ref.child("Users")
    private var EventsInfo = DB_ref.child("Events Information")
    
  
    var name:String = ""
    var email:String = ""
    var mobile:String = ""
    
    
    static let instance = DataServices()    

    func getUserData(UserMobile: String){
        users.child("Id_\(UserMobile)").observeSingleEvent(of: .value, with: { (snapshot) in
        if let user = User(snapshot: snapshot) {
            self.name = user.username
            self.email = user.email
            self.mobile = user.mobile
        } else {
            print("New user!")
        }
   
        })
    }

    // create an account for users
    func createAccount(uName :String , email: String , mobile:String,password:String){
        let userData:[String:Any] = [
            "Name":uName,
            "Email":email,
            "Mobile Number":mobile,
            "Password":password
        ]
        users.child("Id_\(mobile)").setValue(userData)// or -> users.child("Id_\(Int.random(in: 0..<1000))").setValue(userData)
        getUserData(UserMobile: mobile)
    }
    // registeration the users
    
    func registaration(uname:String , email:String , gender:String ,mobileNum:String,date_of_birth:String,eventType:String!){
        
        let registarationData:[String:Any] = [
            "Name":uname,
            "Email":email,
            "Mobile Number":mobileNum,
            "Gender":gender,
            "Date of Birth":date_of_birth,
            "Event":eventType!
        ]
        registareation_events.child("Id_\(mobileNum)").setValue(registarationData)// or -> users.child("Id_\(Int.random(in: 0..<1000))").setValue(userData)
    }
    
    // signin the users
    func signInBtn(mobileNum:String) -> Bool{
        users.child("Id_\(mobileNum)").observeSingleEvent(of: .value) { (snapshot) in
            guard let value = snapshot.value as? [String:Any] else{return}
            }
        return true
        }
        
    }
    
    

