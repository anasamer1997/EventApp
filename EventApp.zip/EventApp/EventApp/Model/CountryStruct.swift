//
//  CountryStruct.swift
//  AlamofireApp
//
//  Created by mac on 19/01/2021.
//

import Foundation

struct CountryStruct:Codable{

    let title: String
    let description: String
}
