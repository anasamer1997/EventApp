//
//  User.swift
//  AlamofireApp
//
//  Created by mac on 13/01/2021.
//

import Foundation
import FirebaseDatabase.FIRDataSnapshot

class User{
    
    let mobile: String
    let username: String
    let email : String
    
        // MARK: - Ini
        
    init(mobile: String, username: String , email: String) {
            self.mobile = mobile
            self.username = username
            self.email = email
    }
   
    init?(snapshot: DataSnapshot) {
        guard let dict = snapshot.value as? [String : Any],
            let username = dict["Name"] as? String,
            let email = dict["Email"] as? String,
            let mobile = dict["Mobile Number"] as? String
            else { return nil }

        self.mobile = mobile
        self.username = username
        self.email = email
    
    }
    
}
