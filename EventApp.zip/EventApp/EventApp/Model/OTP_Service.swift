//
//  OTP_Service.swift
//  AlamofireApp
//
//  Created by mac on 17/01/2021.
//

import FirebaseAuth

class OTP_Serviec {
    
    func getVerificationId(phoneNumber: String, completionHandler: @escaping (String?, Error?) -> Void){
             
            PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber, uiDelegate: nil) { (verificationID, error) in
                 
                if let error = error {
                    completionHandler(nil, error)
                }
                 
                if let id = verificationID {
                    completionHandler(id, nil)
                }
            }
        }
    
    func signIn(verificationId: String, verificationCode: String, completionHandler: @escaping (String?, Error?) -> Void){
         
        let credential = PhoneAuthProvider.provider().credential(withVerificationID: verificationId, verificationCode: verificationCode)
         
        Auth.auth().signIn(with: credential) { (user, error) in
        
            if let error = error {
                completionHandler("Error", error)
            }
            completionHandler("Success", nil)
        }
    }
    
}
