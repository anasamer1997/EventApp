//
//  UserDataStruct.swift
//  AlamofireApp
//
//  Created by mac on 11/01/2021.
//

//import Foundation
//
//struct UserData:Codable {
//    let name:String
//    let email:String
//    let mobile:String
//}
