//
//  DataServiceVCViewController.swift
//  AlamofireApp
//
//  Created by mac on 02/01/2021.
//

import Foundation

class DataService{

    private var users = DB_ref.child("Users")
  
    static let instance = DataService()

    func createAccount(uName :String , email: String , mobile:String){
//
//        users.child("id").setValue("\(mobile)") // or this -> users.child("id").setValue("\(Int.random(in: 0..<100))") to make random id
//        users.child("id/Name").setValue("\(uName)")
//        users.child("id/Email").setValue("\(email)")
//        users.child("id/Mobile Number").setValue("\(mobile)")
       
        
        let userData:[String:Any] = [
            "Name":uName,
            "Email":email,
            "Mobile Number":mobile
        ]
   
        users.child("Id_\(mobile)").setValue(userData)// or -> users.child("Id_\(Int.random(in: 0..<1000))").setValue(userData)
    }
        
    func signInBtn(mobileNum:String){
        users.child("Id_\(mobileNum)").observeSingleEvent(of: .value) { (snapshot) in
            guard let value = snapshot.value as? [String:Any] else{return}
//            if !value.isEmpty{
//                }
            
            }
        }
        
     }
