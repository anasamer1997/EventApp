//
//  DataService.swift
//  AlamofireApp
//
//  Created by mac on 31/12/2020.
//

import Foundation
import FirebaseDatabase


class DataService2{
    
  
 
    
    /////////////////////////////////////////// /////////////////////////////////

    
    }
}


