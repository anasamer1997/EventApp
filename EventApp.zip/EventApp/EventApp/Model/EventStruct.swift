import UIKit
import FirebaseDatabase.FIRDataSnapshot


class EventStruct:Codable {
    
    var event_name = ""
    var Date = ""
    var Location = ""
    var Oraganization = ""
    
    
    init(event_name: String, Date: String , Location: String,Oraganization:String) {
            self.event_name = event_name
            self.Date = Date
            self.Location = Location
            self.Oraganization = Oraganization
    }
   
    init?(snapshot: DataSnapshot) {
        guard let dict = snapshot.value as? [String : Any],
            let Date = dict["Date"] as? String,
            let Location = dict["Location"] as? String,
            let Organization = dict["Organization"] as? String
            else { return nil }
        
        self.Date = Date
        self.Location = Location
        self.Date = Date
        print(self.Date)
    }
    
   
}
